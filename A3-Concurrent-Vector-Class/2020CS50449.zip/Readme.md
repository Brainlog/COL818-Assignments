# Execute the code      
1. For java lock free vector, there is seperate file for lock free vector class and its driver.
2. For cpp both lock free vector and mutex based concurrent vector have class and driver code in same file. Work distribution and number of threads can be changed according to need.
3. Use makefile to run the code.